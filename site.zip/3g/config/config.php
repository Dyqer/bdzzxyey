<?php
$TPL_folder = "default";//templates文件夹下模版文件夹名称
$smarty_cache = false;//是否建立Smarty缓存(性能加速)
?>