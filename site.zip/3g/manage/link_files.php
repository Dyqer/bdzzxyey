<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1">
<meta name="format-detection" content="telephone=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<link href="resource/css/base.css" rel="stylesheet" type="text/css" />
<script src="resource/js/jquery-1.7.1.min.js"></script>
<script src="resource/js/touch.js"></script>