<!--head-->
<div class="box" id="header">
  <div class="logo"><a href="main.php"><img src="resource/image/logo.png" /></a></div>
  <div class="head_index">
    <ul>
      <li><a href="javascript:history.go(-1)"><img src="resource/image/shang.png" /></a></li>
      <li><a href="javascript:window.location.reload()"><img src="resource/image/xh.png" /></a></li>
      <li><a href="main.php"><img src="resource/image/index.png" /></a></li>
    </ul>
  </div>
  <div class="clear"></div>
</div>
<!--headEnd--> 
