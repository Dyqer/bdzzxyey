<?php
/*
 * LCMX 4.0 For Touch 后台公用
 * ============================================================================
 * 版权所有: 山西龙采科技，并保留所有权利。
 * 网站地址: http://www.longcai0351.com
 * ============================================================================
 */
defined('LC_MX_3G_M') or define('LC_MX_3G_M',dirname(dirname(__FILE__)).'/');//系统3G后台目录定义
defined('LC_MX_3G') or define('LC_MX_3G',dirname(LC_MX_3G_M).'/');//系统3G目录定义
require (LC_MX_3G.'common/common.php');//3G核心文件
require (LC_MX_3G_M.'common/functions.php');//后台自定义方法
?>