<link rel="stylesheet" type="text/css" href="resource/css/base.css">
<script src="resource/js/jquery-1.7.2.min.js"></script>
<script src="resource/js/jquery-ui-1.11.2.custom.min.js"></script>
<script src="resource/js/mxui.js"></script>
<script src="resource/js/mx.js"></script>