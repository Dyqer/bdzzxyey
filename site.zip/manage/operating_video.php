<div class="mx_right_top">
    <div class="operatearea">
      <ul class="operateul">
        <li><a style="color: #333;"href="list.php?C=frequently_asked_questions">常见问题</a></li>
        <li><a class="release" href="list.php?C=operating_video">操作视频</a></li>
        <li><a style="color: #333;" href="list.php?C=online_modification">在线修改</a></li>
      </ul>
    </div>
  </div>
<div style="height:13px"></div>
<div>
	<iframe src="http://www.baidusx.com/fncms/shipin.asp" width="80%" height="600" frameborder="0" scrolling="auto"></iframe>
</div>