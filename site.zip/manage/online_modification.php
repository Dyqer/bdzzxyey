<!--fu_right_top-->
<div class="mx_right_top">
    <div class="operatearea">
      <ul class="operateul">
        <li><a style="color: #333;" href="list.php?C=frequently_asked_questions">常见问题</a></li>
        <li><a style="color: #333;" href="list.php?C=operating_video">操作视频</a></li>
        <li><a class="release" href="list.php?C=online_modification">在线修改</a></li>
      </ul>
    </div>
  </div>

<!--end fu_right_top-->
<div style="height: 13px"></div>
<!--fu_right_bottom-->
<div class="fu_right_bottom">
  <div class="zaixian">
    <table width="100%" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td style="padding: 10px"><table width="770" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td class="ghbg" style="padding: 20px" valign="top"><iframe src="http://www.baidusx.com/fncms/zaixianxiugai.asp" width="700" height="300" frameborder="0" scrolling="auto"></iframe></td>
            </tr>
          </table></td>
      </tr>
    </table>
  </div>
</div>
<!--end fu_right_bottom--> 
