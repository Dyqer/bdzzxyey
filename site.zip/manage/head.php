<div class="head" id="header">
  <div class="logo"><a href="main.php" title="MX营销平台">MX营销平台</a></div>
  <div class="head_right">
    <ul>
      <li><a href="../" target="_blank">预览网站</a></li>
      <li><a href="javascript:fankuibug()">Bug反馈</a></li>
      <!--<li><a href="http://e.weibo.com/u/2488214857" target="_blank">官方微博</a></li>-->
      <li><a href="action/exit.php">安全退出</a></li>
    </ul>
  </div>
  <div class="clear"></div>
  <!--提示消息-->
  <div id="msgBox"><span></span></div>
</div>