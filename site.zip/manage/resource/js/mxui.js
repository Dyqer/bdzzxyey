/*
 * init UI For MX Pro
 * 
 * @author : LJay
 * @Email : ljay88@vip.qq.com
 * @date : 20150105
 *
 * Copyright 2015 longcai.com
 */
$(function($){
	$('.Aline>li:odd').css("background","#f2f2f2");
	/*其他*/
	/*$(".colorList").lineColor("li");//间隔
	$(".colorList").listColor("li");//hover
	$(".sel ul").listColor("li");//hover
	$(".sel").selSim("h3","ul","li");//下拉选择
	$(".sel").each(function(){
		$(this).clickTegglo($(this),"ul.selList",10);
	});
	$(".textCo").inputFocus();//输入框高亮*/
	/*其他*/
});