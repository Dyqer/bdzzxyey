<?php
$dbhost = '127.0.0.1'; //数据库地址
$dbuser = 'bdzzxyey_yey'; //用户名
$dbpass = 'm&TTtkS9UKA2'; //密码
$dbname = 'bdzzxyey_db'; //表名
$lc = 'mx_'; //表前缀
?>
