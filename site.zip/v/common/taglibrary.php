<?php
/*
 * LCMX 4.0 For Micro Website Smarty页面标签设置
 */
$_CONFIG['now_url']='http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];//获取当前的网址
?>