<?php
/**************************************************
 * Micro website 核心公用
 **************************************************/
defined('LC_MX') or define('LC_MX',dirname(dirname(dirname(__FILE__))).'/');//系统目录定义
defined('LC_MX_V') or define('LC_MX_V',dirname(dirname(__FILE__)).'/');//系统3G目录定义
require(LC_MX.'common/core.php');//加载核心文件
?>